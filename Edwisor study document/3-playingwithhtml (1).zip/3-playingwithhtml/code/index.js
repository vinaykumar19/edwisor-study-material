$(document).ready(() => {

	$("#someRandomId").empty();
	

	
})// end doc ready