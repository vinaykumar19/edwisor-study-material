$(document).ready(() => {


    
    $("div").not(".paragraph")
    .addClass('highlight');
   







}) // end doc ready