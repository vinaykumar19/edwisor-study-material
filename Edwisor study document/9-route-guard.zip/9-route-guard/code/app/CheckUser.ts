export interface CheckUser {
    checkStatus(): any;
}