//this is a typscript file 

let myFirstVariable:String = "Hello World Changed"

console.log(myFirstVariable)