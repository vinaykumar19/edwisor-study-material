"use strict";
//this is a typscript file 
var myFirstVariable = "Hello World Changed";
console.log(myFirstVariable);
